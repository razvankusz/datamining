import numpy as np
from sklearn.cluster import KMeans


def cluster_baseline(adj_matrix, k):
    n, m = adj_matrix.shape
    assert n == m

    eigvalues, eigvectors = np.linalg.eig(adj_matrix)

    ind = eigvalues.argsort()[:k]
    eigvalues = eigvalues[ind]
    eigvectors = eigvectors[:, ind]

    kmeans = KMeans(n_clusters=k)
    kmeans.fit(eigvectors)
    return kmeans.labels_
