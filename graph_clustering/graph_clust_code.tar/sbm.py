import numpy as np
import numpy.random as rand


def stochastic_block_model(n_vert, n_clust, p_in_plus, p_in_minus, p_out_plus, p_out_minus):
    W_plus = np.zeros((n_vert, n_vert))
    W_minus = np.zeros((n_vert, n_vert))

    for i in range(n_vert):
        for j in range(i + 1, n_vert):
            if (i % n_clust == j % n_clust):
                if (rand.uniform() <= p_in_plus):
                    W_plus[i, j] = 1
                    W_plus[j, i] = 1
                if (rand.uniform() <= p_in_minus):
                    W_minus[i, j] = 1
                    W_minus[j, i] = 1
            else:
                if (rand.uniform() <= p_out_plus):
                    W_plus[i, j] = 1
                    W_plus[j, i] = 1
                if (rand.uniform() <= p_out_minus):
                    W_minus[i, j] = 1
                    W_minus[j, i] = 1
            if W_minus[i, j] == W_plus[i, j]:
                W_minus[i, j] = 0
                W_plus[i, j] = 0
                W_minus[j, i] = 0
                W_plus[j, i] = 0
    correct_labels = [x % n_clust for x in range(n_vert)]
    return W_plus, W_minus, correct_labels
