import random
from itertools import izip

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import numpy.random as rand
from scipy.linalg import sqrtm
import scipy.spatial.distance

from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.neighbors import kneighbors_graph, DistanceMetric
import sklearn.datasets as datasets


def get_diag(A, as_vector=False):
    n, m = A.shape
    assert n == m

    diag_elements = np.dot(A, np.ones((n, 1)))

    diag_elements = np.reshape(diag_elements, newshape=(n, ))
    if not as_vector:
        return np.diag(diag_elements)
    else:
        return diag_elements


def get_diag_square_inverse(D):

    def inverse_square(x):
        return 1.0 / pow(x, .5)

    diag_elements = get_diag(D, True)
    diag_elements = np.vectorize(inverse_square)(diag_elements)
    return np.diag(diag_elements)


def get_normalized_laplacian(A):
    D = get_diag(A)
    L = D - A
    D_sqrt_inv = get_diag_square_inverse(D)
    return np.dot(np.dot(D_sqrt_inv, L), D_sqrt_inv)


def get_normalized_signless_laplacian(A):
    D = get_diag(A)
    W = D + A
    D_sqrt_inv = get_diag_square_inverse(D)
    return np.dot(np.dot(D_sqrt_inv, W), D_sqrt_inv)


def up_shift(A, epsilon):
    n, m = A.shape
    assert n == m

    I = np.diag(np.ones((n, )))
    return A + epsilon * I


def geometric_mean(A, B):
    ''' A#B = A(A^-1* B)^1/2
    '''
    return np.dot(A,
                  sqrtm(np.dot(
                      np.linalg.inv(A),
                      B)))


def compute_LSR(W_plus, W_minus):
    D = get_diag(W_plus) + get_diag(W_minus)
    return D - W_plus + W_minus


def compute_LSN(W_plus, W_minus):
    D = get_diag(W_plus) + get_diag(W_minus)
    D_sqrt = get_diag_square_inverse(D)
    LSR = compute_LSR(W_plus, W_minus)
    return np.dot(np.dot(D_sqrt, LSR), D_sqrt)


def compute_LBR(W_plus, W_minus):
    D_plus = get_diag(W_plus)
    return D_plus - W_plus + W_minus


def compute_LBN(W_plus, W_minus):
    D = get_diag(W_plus) + get_diag(W_minus)
    Dinv = np.linalg.inv(D)
    LBR = compute_LBR(W_plus, W_minus)
    return np.dot(Dinv, LBR)


def compute_LGM(W_plus, W_minus):
    n, m = W_plus.shape
    assert n == m

    LSim = get_normalized_laplacian(W_plus)
    LSim = up_shift(LSim, 0.001)

    QSim = get_normalized_signless_laplacian(W_minus)
    QSim = up_shift(QSim, 0.001)

    LGM = geometric_mean(LSim, QSim)
    return LGM


def compute_LAM(W_plus, W_minus):
    n, m = W_plus.shape
    assert n == m

    LSim = get_normalized_laplacian(W_plus)
    LSim = up_shift(LSim, 0.001)

    QSim = get_normalized_signless_laplacian(W_minus)
    QSim = up_shift(QSim, 0.001)

    LAM = LSim + QSim
    return LAM


def isSym(A):
    return np.allclose(A, A.T, 0.001)


def cluster_baseline(adj_matrix, k):
    n, m = adj_matrix.shape
    assert n == m

    eigvalues, eigvectors = np.linalg.eig(adj_matrix)

    ind = eigvalues.argsort()[:k]
    eigvalues = eigvalues[ind]
    eigvectors = eigvectors[:, ind]

    kmeans = KMeans(n_clusters=k)
    kmeans.fit(eigvectors)
    return kmeans.labels_


def cluster_LBR(W_plus, W_minus, k):
    LBR = compute_LBR(W_plus, W_minus)
    return cluster_baseline(LBR, k)


def cluster_LSN(W_plus, W_minus, k):
    LSN = compute_LSN(W_plus, W_minus)
    return cluster_baseline(LSN, k)


def cluster_LBN(W_plus, W_minus, k):
    LBN = compute_LBN(W_plus, W_minus)
    return cluster_baseline(LBN, k)


def cluster_LAM(pos_weights, neg_weights, k):
    LAM = compute_LAM(pos_weights, neg_weights)
    return cluster_baseline(LAM, k)


def cluster_LGM(pos_weights, neg_weights, k):
    LGM = compute_LGM(pos_weights, neg_weights)
    return cluster_baseline(LGM, k)


def cluster_LSym(weights, k):
    LSym = get_normalized_laplacian(weights)
    return cluster_baseline(LSym, k)


def display_graph(W_plus, W_minus):
    n, m = W_plus.shape

    G = nx.Graph()
    for i in range(n):
        G.add_node(i)

    pos_edge = [(i, j) for i in range(n)
                for j in range(n) if W_plus[i, j] == 1]
    neg_edge = [(i, j) for i in range(n)
                for j in range(n) if W_minus[i, j] == 1]
    for (i, j) in pos_edge:
        G.add_edge(i, j, attr_dict={'weight': 1000})
    for (i, j) in neg_edge:
        G.add_edge(i, j, attr_dict={'weight': -1})

    # nx.draw_spring(G, edgelist=pos_edge, edge_color='r', with_labels=True)
    # nx.draw_spring(G, edgelist=neg_edge, edge_color='b', with_labels=True)

    nx.draw_spring(G)
    plt.show()


def main():
    A = np.array([[0, 2, 3],
                  [2, 0, 1],
                  [3, 1, 0]])
    B = np.array([[0, 2, 2],
                  [2, 0, 1],
                  [2, 1, 0]])

    params = {
        'p_in_plus': 0.08,
        'p_out_plus': 0.075,
        'p_in_minus': 0.01,
        'p_out_minus': 0.09,
    }

    W_plus, W_minus, correct_labels = stochastic_block_model(
        1000, 5, **params)


def process_sklearn_dataset(data, target, k_plus, k_minus):
    def inverse_dist(x, y):
        return 1 / (scipy.spatial.distance.euclidean(x, y) + 0.01)

    W_plus = kneighbors_graph(
        data, k_plus, mode='connectivity', metric='euclidean')

    W_minus = kneighbors_graph(
        data, k_minus, mode='connectivity', metric=inverse_dist)
    return W_plus.toarray(), W_minus.toarray()


def ks_grid_search(data, target, n_clusters, ks, verbose=True):
    ks = [3, 5, 10, 20, 30, 40, 100]

    results = []
    for k_plus in ks:
        for k_minus in ks:
            result = W_plus, W_minus = process_sklearn_dataset(
                data, target, k_plus, k_minus)
            result = run_suite(W_plus, W_minus, 3, target)
            results.append((k_plus, k_minus, result))

    if verbose:
        for (k_plus, k_minus, result) in results:
            lsn, lbn, lam, lgm = result
            print "K+: {}, K-: {}".format(k_plus, k_minus)
            print "LSN {}, LBN {}, LAM {}, LGM {}".format(lsn, lbn, lam, lgm)
    return results


def verify_conditions(k, p_in_plus, p_out_plus, p_in_minus, p_out_minus):
    result = []

    if (p_out_plus < p_in_plus):
        result.append("E+")
    if (p_in_minus < p_out_minus):
        result.append("E-")
    if (p_in_minus + p_out_plus < p_in_plus + p_out_minus):
        result.append("E-bal")
    if (p_in_minus + (k - 1.0) * p_out_minus <
            p_in_plus + (k - 1.0) * p_out_plus):
        result.append("E-vol")

    term_plus = (k * p_out_plus) / (p_in_plus + (k - 1.0) * p_out_plus)
    term_minus = (k * p_in_minus) / (p_in_minus + (k - 1.0) * p_out_minus)
    term_2G = (p_in_minus - p_out_minus) / \
        (p_in_minus + (k - 1.0) * p_out_minus)

    if (term_plus * term_minus < 1.0):
        result.append("E-conf")
    if (term_plus * (1.0 + term_2G) < 1.0):
        result.append("EG")
    return result


if __name__ == '__main__':
    data, target = datasets.load_digits(return_X_y=True)

    # W_plus, W_minus = process_sklearn_dataset(data, target, 30, 40)
    # run_suite(W_plus, W_minus, 10, target)

    params = {
        'p_in_plus': 0.08,
        'p_out_plus': 0.075,
        'p_in_minus': 0.01,
        'p_out_minus': 0.09,
    }

    # print verify_conditions(5, **params)

    # W_plus, W_minus, target = stochastic_block_model(1000, 3, **params)

    # run_suite(W_plus, W_minus, 5, target)

    # plt.matshow(W_minus)
    # plt.matshow(W_plus)
    # plt.show()
    # # plt.matshow(W_minus)
    # plt.matshow(W_plus)
    # # display_graph(W_plus, W_minus)
    # plt.show()
