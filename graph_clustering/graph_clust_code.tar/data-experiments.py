import sys
import time
import cPickle as pickle
import scipy
import sklearn.datasets as datasets
from sklearn import metrics
from sklearn.neighbors import DistanceMetric, kneighbors_graph
from mpl_toolkits.mplot3d import axes3d   # import a library to allow 3d plots

from clustering import (cluster_LAM, cluster_LBN, cluster_LGM, cluster_LSN,
                        cluster_LSym, up_shift, get_diag_square_inverse, get_diag)
from sbm import stochastic_block_model
import numpy as np
import matplotlib.pyplot as plt


def run_suite(W_plus, W_minus, k, target, verbose=False):
    if verbose:
        print "Computing rand score..."
    labels = cluster_LGM(W_plus, W_minus, k)
    lgm = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LBN(W_plus, W_minus, k)
    lbn = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LAM(W_plus, W_minus, k)
    lam = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LSN(W_plus, W_minus, k)
    lsn = metrics.adjusted_rand_score(target, labels)

    if verbose:
        print "LSN, ", lsn
        print "LBN, ", lbn
        print "LAM, ", lam
        print "LGM, ", lgm

    return (lsn, lbn, lam, lgm)


def sklearn_dataset_to_signed(data, target, k_plus, k_minus):
    def inverse_dist(x, y):
        return 1 / (scipy.spatial.distance.euclidean(x, y) + 0.01)

    W_plus = kneighbors_graph(
        data, k_plus, mode='connectivity', metric='euclidean')

    W_minus = kneighbors_graph(
        data, k_minus, mode='connectivity', metric=inverse_dist)
    return W_plus.toarray(), W_minus.toarray()


def sklearn_dataset_to_unsigned(data, target, k):
    W = kneighbors_graph(
        data, k, mode='connectivity', metric='euclidean')
    return W.toarray()


def experiment(data, target, n_classes, k_plus, k_minus):

    W_plus, W_minus = sklearn_dataset_to_signed(data, target, k_plus, k_minus)
    W = sklearn_dataset_to_unsigned(data, target, k_plus + k_minus)

    labels = cluster_LSym(W, n_classes)
    lsim = metrics.adjusted_rand_score(target, labels)
    results = run_suite(W_plus, W_minus, n_classes, target)

    return (lsim, ) + results


def experiment1(filename):

    with open(filename, 'w+') as f:

        f.write('iris\n')
        data, target = datasets.load_iris(return_X_y=True)
        results = experiment(data, target, 3, 30, 40)
        f.write('{}, {}, {}, {}, {}\n'.format(*results))

        f.write('digits\n')
        data, target = datasets.load_digits(return_X_y=True)
        results = experiment(data, target, 10, 30, 40)
        f.write('{}, {}, {}, {}, {}\n'.format(*results))

        f.write('wine\n')
        data, target = datasets.load_digits(return_X_y=True)
        results = experiment(data, target, 3, 30, 40)
        f.write('{}, {}, {}, {}, {}\n'.format(*results))


def experiment2(filename):
    '''
    optimising the choice of k for the LGM
    '''
    kvals = np.array(range(10, 110, 20))
    with open(filename, 'w+') as f:
        f.write('digits\n')
        f.write('10, 100, 10\n')

        data, target = datasets.load_breast_cancer(return_X_y=True)
        # data, target = read_ecoli()
        i = 1
        for k_plus in kvals:
            for k_minus in kvals:
                print i
                i = i + 1
                try:
                    results = experiment(data, target, 4, k_plus, k_minus)
                    f.write('{}, {}, {}, {}, {}\n'.format(*results))
                except:
                    f.write('0.0, 0.0, 0.0, 0.0, 0.0\n')


def read_ecoli():
    X = []
    y = []

    def to_tag(s):
        if 'cp' in s:
            return 0
        if 'im' in s:
            return 1
        if 'om' in s:
            return 2
        if 'pp' in s:
            return 3

    with open('ecoli.txt') as f:

        line = f.readline()
        while line:
            line = line.split()
            X.append([float(x) for x in line[1:-1]])
            y.append(to_tag(line[len(line) - 1]))
            line = f.readline()
    return np.array(X), np.array(y)


def read_experiment2(filename):
    with open(filename) as f:
        f.readline()
        params = [int(value) for value in f.readline().split(',')]
        X = np.arange(10, 110, 10)
        Y = np.arange(10, 110, 10)
        X, Y = np.meshgrid(X, Y)
        line = f.readline()
        values = np.array([[float(value) for value in line.split(',')]])

        while line:
            line = f.readline()
            try:
                print line.split(',')
                values = np.append(values, np.array(
                    [[float(value) for value in line.split(',')]]), axis=0)
            except:
                pass

    # lgms = values[:, 4].reshape(10, 10)
    # plt.imshow(lgms, extent=np.array(
    #     [10, 100, 10, 100]), cmap=plt.get('coolwarm'), origin='lower')
    # plt.colorbar()
    # plt.savefig('wine-lgm-colmap.eps')

    print '%.3f' % max(values[:, 0]), ' & ', '%.3f' % max(values[:, 1]), ' & ', '%.3f' % max(values[:, 2]), ' & ', '%.3f' % max(values[:, 3]), ' & ', '%.3f' % max(values[:, 4])


def reduce_matrix(W_plus, W_minus):
    '''we need connected graphs'''

    plus_columns = ~np.all(W_plus == 0, axis=0)
    plus_lines = ~np.all(W_plus == 0, axis=1)

    while np.any(plus_columns == False) or np.any(plus_lines == False):

        W_plus = W_plus[:, plus_columns]
        W_plus = W_plus[plus_lines, :]
        W_minus = W_minus[:, plus_columns]
        W_minus = W_minus[plus_lines, :]

        minus_columns = ~np.all(W_minus == 0, axis=0)
        minus_lines = ~np.all(W_minus == 0, axis=1)

        W_plus = W_plus[:, minus_columns]
        W_plus = W_plus[minus_lines, :]
        W_minus = W_minus[:, minus_columns]
        W_minus = W_minus[minus_lines, :]

        plus_columns = ~np.all(W_plus == 0, axis=0)
        plus_lines = ~np.all(W_plus == 0, axis=1)

    return W_plus, W_minus


def bitcoin_experiment(filename):
    my_data = np.genfromtxt('./soc-sign-bitcoinalpha.csv', delimiter=',')
    start = my_data[:, 0].astype(int)
    end = my_data[:, 1].astype(int)
    weight = my_data[:, 2]

    k = 4

    n_vert = 8000

    W_plus = np.zeros((n_vert, n_vert))
    W_minus = np.zeros((n_vert, n_vert))

    for i, (x, y) in enumerate(zip(start, end)):
        if weight[i] > 0:
            W_plus[x, y] = weight[i]
            W_plus[y, x] = weight[i]
        else:
            W_minus[x, y] = - weight[i]
            W_minus[y, x] = - weight[i]

    W_plus, W_minus = reduce_matrix(W_plus, W_minus)

    labels = cluster_LGM(W_plus, W_minus, k)
    sorted_indeces = np.argsort(labels)

    plt.imshow(W_plus[sorted_indeces, :][:, sorted_indeces], cmap='coolwarm')
    plt.savefig('docs/bitcoin-alpha-plus.eps')
    plt.imshow(W_minus[sorted_indeces, :][:, sorted_indeces], cmap='Reds')
    plt.savefig('docs/bitcoin-alpha-minus.eps')


def wikipedia_save_data(filename):
    counter = 0
    usernames = {}

    W_plus = np.zeros((11402, 11402))
    W_minus = np.zeros((11402, 11402))

    with open('rfa_all.NL-SEPARATED.txt', 'r') as f:
        line = f.readline()
        x = 0
        y = 0
        while line:
            if line.startswith('SRC:'):
                src = line[4:]
                if src in usernames:
                    x = usernames[src]
                else:
                    usernames[src] = counter
                    x = counter
                    counter = counter + 1
            elif line.startswith('TGT:'):
                tgt = line[4:]
                if tgt in usernames:
                    y = usernames[tgt]
                else:
                    usernames[tgt] = counter
                    y = counter
                    counter = counter + 1
            elif line.startswith('VOT:'):
                vot = int(line[4:])
                if vot > 0:
                    W_plus[x, y] = vot
                    W_plus[y, x] = vot
                elif vot < 0:
                    W_minus[x, y] = - vot
                    W_minus[y, x] = - vot
            line = f.readline()
    W_plus, W_minus = reduce_matrix(W_plus, W_minus)

    return W_plus, W_minus
    np.savez('wiki_rfa_mat.npz', W_plus=W_plus, W_minus=W_minus)


def wikipedia_experiment(filename):
    print 'reading data'
    W_plus, W_minus = wikipedia_save_data(filename)

    # Ws = np.load('wiki_rfa_mat.npz')
    # W_plus = Ws['W_plus']
    # W_minus = Ws['W_minus']

    k = 5
    print 'clustering now'
    labels = cluster_LGM(W_plus, W_minus, k)
    sorted_indeces = np.argsort(labels)

    plt.imshow(W_minus[sorted_indeces, :][:, sorted_indeces])
    plt.show()
    # with open('wiki_rfa_mat.dat', 'rb') as f:
    #     W_plus, W_minus = pickle.load(f)


if __name__ == '__main__':
    if len(sys.argv) == 2:
        if (sys.argv[1] == '1'):
            print 'starting exp1'
            # experiment1('experiment1.txt')
        if (sys.argv[1] == '2'):
            print 'starting exp2'
            experiment2('dataexperiment2-bc.txt')
            read_experiment2('dataexperiment2-bc.txt')
        if (sys.argv[1] == '3'):
            print 'starting exp3'
            # experiment3('experiment3.txt')
        if (sys.argv[1] == '4'):
            print 'starting bitcoin experiment'
            bitcoin_experiment('a')
        if (sys.argv[1] == '5'):
            print 'starting wikipedia experiment'
            wikipedia_experiment('a')
