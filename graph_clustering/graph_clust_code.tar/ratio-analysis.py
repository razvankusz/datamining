import numpy as np


def main():
    with open('dataexperiment2-bc.txt') as f:
        line = f.readline()
        line = f.readline()
        line = f.readline()
        values = np.array([[float(value) for value in line.split(',')]])

        while line:
            line = f.readline()
            try:
                print line.split(',')
                values = np.append(values, np.array(
                    [[float(value) for value in line.split(',')]]), axis=0)
            except:
                pass

    counts = [0, 0, 0, 0, 0]

    for value in values:
        i = np.argmax(value)
        counts[i] = counts[i] + 1
        for j in range(0, 5):
            if value[j] == value[i]:
                counts[j] = counts[j] + 1
    total = sum(counts)

    counts = [float(x) / total for x in counts]

    print ' & ', '%.3f' % counts[0], ' & ', '%.3f' % counts[1], ' & ', '%.3f' % counts[2], ' & ', '%.3f' % counts[3], ' & ', '%.3f' % counts[4]


if __name__ == '__main__':
    main()
