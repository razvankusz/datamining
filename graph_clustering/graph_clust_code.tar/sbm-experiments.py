import random
import sys
import time
import matplotlib
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt
from clustering import (cluster_LAM, cluster_LBN, cluster_LGM, cluster_LSN,
                        cluster_LSym)
from sbm import stochastic_block_model


def run_suite(W_plus, W_minus, k, target, verbose=False):
    if verbose:
        print "Computing rand score..."
    labels = cluster_LSym(W_plus, k)
    lsim = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LGM(W_plus, W_minus, k)
    lgm = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LBN(W_plus, W_minus, k)
    lbn = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LAM(W_plus, W_minus, k)
    lam = metrics.adjusted_rand_score(target, labels)

    labels = cluster_LSN(W_plus, W_minus, k)
    lsn = metrics.adjusted_rand_score(target, labels)

    if verbose:
        print "Lsym, ", lsim
        print "LSN, ", lsn
        print "LBN, ", lbn
        print "LAM, ", lam
        print "LGM, ", lgm

    return (lsn, lbn, lam, lgm)


def verify_conditions(k, p_in_plus, p_out_plus, p_in_minus, p_out_minus):
    result = []

    if (p_out_plus < p_in_plus):
        result.append("E+")
    if (p_in_minus < p_out_minus):
        result.append("E-")
    if (p_in_minus + p_out_plus < p_in_plus + p_out_minus):
        result.append("E-bal")
    if (p_in_minus + (k - 1.0) * p_out_minus <
            p_in_plus + (k - 1.0) * p_out_plus):
        result.append("E-vol")

    term_plus = (k * p_out_plus) / (p_in_plus + (k - 1.0) * p_out_plus)
    term_minus = (k * p_in_minus) / (p_in_minus + (k - 1.0) * p_out_minus)
    term_2G = (p_in_minus - p_out_minus) / \
        (p_in_minus + (k - 1.0) * p_out_minus)

    if (term_plus * term_minus < 1.0):
        result.append("E-conf")
    if (term_plus * (1.0 + term_2G) < 1.0):
        result.append("EG")
    return result


def conditions_to_tags(conditions):
    '''
    tag = 0 means no interesting conditions hold
    tag = 1 means LAM, LSN, LBN should outperform
    tag = 2 means LGM should outperform
    tag = 3 means all axioms hold
    '''

    tag = 0
    if ('E+' in conditions) and ('E-' in conditions) and ('E-bal' in conditions) and ('E-vol' in conditions):
        tag = tag + 1
    if ('E+' in conditions) and ('E-' in conditions) and ('EG' in conditions):
        tag = tag + 2
    return tag


def explore_parameter_space(k):
    space = np.linspace(0.005, 0.1, 20)
    result = {
        0: [],
        1: [],
        2: [],
        3: []
    }
    for p_in_plus in space:
        for p_out_plus in space:
            for p_in_minus in space:
                for p_out_minus in space:
                    params = {
                        'p_in_plus': p_in_plus,
                        'p_out_plus': p_out_plus,
                        'p_in_minus': p_in_minus,
                        'p_out_minus': p_out_minus
                    }
                    tag = conditions_to_tags(verify_conditions(k, **params))
                    result[tag].append(params)
    return result


def read_experiment2(filename):
    matplotlib.rcParams.update({'font.size': 12})
    ns = np.array(range(1000, 10000, 1000))
    results = np.array([])
    with open(filename, 'r') as f:
        line = f.readline()
        while line:
            line = f.readline()
            results = np.append(results, float(line))
            line = f.readline()
        plt.plot(ns[:7], results[:7], '-', label='time')
        plt.legend()
        plt.title('Time taken for LGM clustering')
        plt.xlabel('n values')
        plt.ylabel('time')
        plt.axis('tight')
        plt.savefig('docs/exp2.eps')
        plt.show()


def read_experiment1(filename):
    matplotlib.rcParams.update({'font.size': 12})
    ks = np.array([])
    results = np.array([])
    with open(filename, 'r') as f:
        line = f.readline()
        ks = np.append(ks, int(line))
        line = f.readline()
        results = np.array([[float(s)
                             for s in line.split(',')]])
        line = f.readline()
        while line:
            ks = np.append(ks, int(line))
            line = f.readline()
            results = np.append(results, np.array(
                [[float(s) for s in line.split(',')]]), axis=0)
            line = f.readline()
        plt.plot(ks[:10], results[:10, 0], '-', label='lsn')
        plt.plot(ks[:10], results[:10, 1], '-', label='lbn')
        plt.plot(ks[:10], results[:10, 2], '-', label='lam')
        plt.plot(ks[:10], results[:10, 3], '-', label='lgn')
        plt.legend()
        plt.title('Clustering score on SBM with increasing number of clusters')
        plt.xlabel('k values')
        plt.ylabel('ARI score')
        plt.axis('tight')
        plt.savefig('docs/exp1.eps')
        plt.show()


def experiment1(filename):

    params = {
        'p_in_plus': 0.08,
        'p_out_plus': 0.075,
        'p_in_minus': 0.01,
        'p_out_minus': 0.09,
    }

    n = 1000

    with open(filename, "w+") as f:
        for k in range(2, 100):
            W_plus, W_minus, target = stochastic_block_model(n, k, **params)
            f.write("{}\n".format(k))
            f.write("{}, {}, {}, {}\n".format(
                *run_suite(W_plus, W_minus, k, target)))


def experiment2(filename):
    params = {
        'p_in_plus': 0.08,
        'p_out_plus': 0.075,
        'p_in_minus': 0.01,
        'p_out_minus': 0.09,
    }

    k = 5

    with open(filename, "w+") as f:
        for n in range(1000, 10000, 1000):
            print n
            W_plus, W_minus, target = stochastic_block_model(n, k, **params)
            f.write("{}\n".format(k))
            try:
                start = time.time()
                cluster_LGM(W_plus, W_minus, k)
                end = time.time()
                f.write("{}\n".format(end - start))
            except:
                f.write('failed')


def read_experiment3(filename):
    pass


def experiment3(filename):
    n = 1000
    k = 5

    # 5 samples from each tag
    params_map = explore_parameter_space(k)

    with open(filename, 'w+') as f:
        '''
        print tag, params, results
        '''

        paramss = random.sample(params_map[3], 15)
        for params in paramss:
            W_plus, W_minus, target = stochastic_block_model(
                n, k, **params)

            f.write('{}, {}, {}, {}\n'.format(*params.values()))
            try:
                f.write("{}, {}, {}, {}\n".format(
                    *run_suite(W_plus, W_minus, k, target)))
            except:
                f.write('failed\n')
            f.flush()


def main(arg):
    experiment1('experiment1.txt')
    experiment2('experiment2.txt')


if __name__ == '__main__':
    print sys.argv
    if len(sys.argv) == 2:
        if (sys.argv[1] == '1'):
            print 'starting exp1'
            read_experiment1('experiment1.txt')
        if (sys.argv[1] == '2'):
            print 'starting exp2'
            read_experiment2('experiment2.txt')
        if (sys.argv[1] == '3'):
            print 'starting exp3'
            experiment3('experiment3.txt')
