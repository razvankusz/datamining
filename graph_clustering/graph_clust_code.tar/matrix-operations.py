def compute_LGM(W_plus, W_minus):
    n, m = W_plus.shape
    assert n == m

    LSim = get_normalized_laplacian(W_plus)
    LSim = up_shift(LSim, 0.001)

    QSim = get_normalized_signless_laplacian(W_minus)
    QSim = up_shift(QSim, 0.001)

    LGM = geometric_mean(LSim, QSim)
    return LGM
