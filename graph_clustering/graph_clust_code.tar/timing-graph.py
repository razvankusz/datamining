import matplotlib.pyplot as plt

n = [1000, 2000, 3000, 4000, 5000, 6000, 7000]
t = [
    10.1817090511,
    125.44072485,
    317.462650061,
    642.544387102,
    1033.77570081,
    1761.28612208,
    2914.00918007]

plt.plot(n, t)
plt.title('Running time of the LGM clustering algorithm')
plt.xlabel('Number of vertices')
plt.ylabel('Time for LGM clustering')
plt.axis('tight')
plt.savefig('docs/time1.eps')
plt.show()
